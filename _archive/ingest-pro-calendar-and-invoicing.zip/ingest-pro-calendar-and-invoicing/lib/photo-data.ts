export interface Photo {
  id: string
  filename: string
  thumbnail: string
  fullSize: string
  dateTaken: string
  camera: string
  lens: string
  aperture: number
  shutterSpeed: string
  iso: number
  focalLength: number
  dimensions: string
  fileSize: string
  fileType: "RAW" | "JPG" | "TIFF"
  tags: string[]
  starred: boolean
  culled: boolean
  rating: number
  rotation: number
  userOrder: number
  gps?: {
    lat: number
    lng: number
    location: string
  }
}

const cameras = ["Canon EOS R5", "Canon EOS R6", "Sony A7 IV", "Sony A7R V", "Nikon Z8"]

const lenses = [
  "RF 24-70mm f/2.8",
  "RF 70-200mm f/2.8",
  "RF 85mm f/1.2",
  "RF 50mm f/1.2",
  "RF 35mm f/1.4",
  "RF 15-35mm f/2.8",
]

const tags = [
  "Portrait",
  "Landscape",
  "Wedding",
  "Ceremony",
  "Reception",
  "Detail",
  "Candid",
  "Posed",
  "B&W Candidate",
  "Hero Shot",
  "Album Pick",
  "Client Favorite",
]

const locations = [
  { lat: 37.7749, lng: -122.4194, location: "San Francisco, CA" },
  { lat: 34.0522, lng: -118.2437, location: "Los Angeles, CA" },
  { lat: 40.7128, lng: -74.006, location: "New York, NY" },
]

const apertures = [1.2, 1.4, 1.8, 2.0, 2.8, 4.0, 5.6, 8.0, 11, 16]
const isos = [100, 200, 400, 800, 1600, 3200, 6400]
const shutterSpeeds = ["1/8000s", "1/4000s", "1/2000s", "1/1000s", "1/500s", "1/250s", "1/125s", "1/60s"]
const focalLengths = [15, 24, 35, 50, 70, 85, 100, 135, 200]

function randomElement<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)]
}

function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

export function generateMockPhotos(count: number, startIndex = 0): Photo[] {
  const baseTime = new Date()
  baseTime.setHours(14, 0, 0, 0)

  return Array.from({ length: count }, (_, i) => {
    const index = startIndex + i
    const timeTaken = new Date(baseTime.getTime() + i * randomInt(30000, 300000))
    const focalLength = randomElement(focalLengths)
    const camera = randomElement(cameras)
    const lens = randomElement(lenses)

    // Generate a photo query based on tags
    const photoTags = Array.from({ length: randomInt(1, 3) }, () => randomElement(tags)).filter(
      (v, i, a) => a.indexOf(v) === i,
    )

    const queryHint = photoTags[0] || "professional photography"

    return {
      id: `photo-${index}`,
      filename: `IMG_${String(index + 1000).padStart(4, "0")}.${Math.random() > 0.3 ? "CR3" : "JPG"}`,
      thumbnail: `/placeholder.svg?height=200&width=200&query=${encodeURIComponent(queryHint + " photo " + index)}`,
      fullSize: `/placeholder.svg?height=1200&width=1800&query=${encodeURIComponent(queryHint + " professional " + index)}`,
      dateTaken: timeTaken.toISOString(),
      camera,
      lens,
      aperture: randomElement(apertures),
      shutterSpeed: randomElement(shutterSpeeds),
      iso: randomElement(isos),
      focalLength,
      dimensions: "8192 × 5464",
      fileSize: `${randomInt(25, 65)}.${randomInt(0, 9)} MB`,
      fileType: Math.random() > 0.3 ? "RAW" : "JPG",
      tags: photoTags,
      starred: Math.random() > 0.85,
      culled: Math.random() > 0.9,
      rating: Math.random() > 0.7 ? randomInt(1, 5) : 0,
      rotation: 0,
      userOrder: index,
      gps: Math.random() > 0.7 ? randomElement(locations) : undefined,
    }
  })
}
