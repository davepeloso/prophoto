"use client"

import { useState } from "react"
import { PhotoManager } from "@/components/photo-manager"
import { PreIngestFlow } from "@/components/pre-ingest-flow"

export default function Page() {
  const [showIngest, setShowIngest] = useState(false)

  return (
    <div className="dark">
      {showIngest ? (
        <PhotoManager />
      ) : (
        <PreIngestFlow onComplete={() => setShowIngest(true)} />
      )}
    </div>
  )
}
