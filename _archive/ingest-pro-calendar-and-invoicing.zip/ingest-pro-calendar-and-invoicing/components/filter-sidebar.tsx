"use client"

import type { Photo } from "@/lib/photo-data"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Slider } from "@/components/ui/slider"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { X } from "lucide-react"
import { cn } from "@/lib/utils"
import { useMemo } from "react"

interface Filters {
  cameras: string[]
  dateRange: [Date, Date] | null
  apertureRange: [number, number] | null
  isoRange: [number, number] | null
  tags: string[]
}

interface FilterSidebarProps {
  open: boolean
  onClose: () => void
  photos: Photo[]
  filters: Filters
  onFiltersChange: (filters: Filters) => void
}

export function FilterSidebar({ open, onClose, photos, filters, onFiltersChange }: FilterSidebarProps) {
  const cameras = useMemo(() => [...new Set(photos.map((p) => p.camera))], [photos])

  const tags = useMemo(() => [...new Set(photos.flatMap((p) => p.tags))], [photos])

  const toggleCamera = (camera: string) => {
    const newCameras = filters.cameras.includes(camera)
      ? filters.cameras.filter((c) => c !== camera)
      : [...filters.cameras, camera]
    onFiltersChange({ ...filters, cameras: newCameras })
  }

  const toggleTag = (tag: string) => {
    const newTags = filters.tags.includes(tag) ? filters.tags.filter((t) => t !== tag) : [...filters.tags, tag]
    onFiltersChange({ ...filters, tags: newTags })
  }

  const clearFilters = () => {
    onFiltersChange({
      cameras: [],
      dateRange: null,
      apertureRange: null,
      isoRange: null,
      tags: [],
    })
  }

  const activeFilterCount =
    filters.cameras.length + filters.tags.length + (filters.apertureRange ? 1 : 0) + (filters.isoRange ? 1 : 0)

  return (
    <div
      className={cn(
        "w-64 border-r border-border bg-card flex flex-col transition-all duration-200",
        !open && "w-0 opacity-0 overflow-hidden",
      )}
    >
      <div className="h-12 px-4 flex items-center justify-between border-b border-border">
        <div className="flex items-center gap-2">
          <span className="font-medium text-sm">Filters</span>
          {activeFilterCount > 0 && (
            <Badge variant="secondary" className="text-xs px-1.5 py-0">
              {activeFilterCount}
            </Badge>
          )}
        </div>
        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-4 space-y-6">
          {/* Camera Filter */}
          <div>
            <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Camera</Label>
            <div className="mt-2 space-y-2">
              {cameras.map((camera) => (
                <div key={camera} className="flex items-center gap-2">
                  <Checkbox
                    id={`camera-${camera}`}
                    checked={filters.cameras.includes(camera)}
                    onCheckedChange={() => toggleCamera(camera)}
                  />
                  <label htmlFor={`camera-${camera}`} className="text-sm cursor-pointer">
                    {camera}
                  </label>
                </div>
              ))}
            </div>
          </div>

          {/* ISO Range */}
          <div>
            <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">ISO Range</Label>
            <div className="mt-3 px-1">
              <Slider
                value={filters.isoRange || [100, 6400]}
                min={100}
                max={6400}
                step={100}
                onValueChange={(value) => onFiltersChange({ ...filters, isoRange: value as [number, number] })}
              />
              <div className="flex justify-between mt-1 text-xs text-muted-foreground">
                <span>{filters.isoRange?.[0] || 100}</span>
                <span>{filters.isoRange?.[1] || 6400}</span>
              </div>
            </div>
          </div>

          {/* Aperture Range */}
          <div>
            <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Aperture Range</Label>
            <div className="mt-3 px-1">
              <Slider
                value={filters.apertureRange || [1.4, 16]}
                min={1.4}
                max={16}
                step={0.1}
                onValueChange={(value) => onFiltersChange({ ...filters, apertureRange: value as [number, number] })}
              />
              <div className="flex justify-between mt-1 text-xs text-muted-foreground">
                <span>f/{filters.apertureRange?.[0].toFixed(1) || "1.4"}</span>
                <span>f/{filters.apertureRange?.[1].toFixed(1) || "16"}</span>
              </div>
            </div>
          </div>

          {/* Tags Filter */}
          <div>
            <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Tags</Label>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {tags.slice(0, 12).map((tag) => (
                <button
                  key={tag}
                  onClick={() => toggleTag(tag)}
                  className={cn(
                    "text-xs px-2 py-1 rounded-md transition-colors",
                    filters.tags.includes(tag) ? "bg-primary text-primary-foreground" : "bg-muted hover:bg-muted/80",
                  )}
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>
        </div>
      </ScrollArea>

      {activeFilterCount > 0 && (
        <div className="p-4 border-t border-border">
          <Button variant="outline" size="sm" className="w-full bg-transparent" onClick={clearFilters}>
            Clear All Filters
          </Button>
        </div>
      )}
    </div>
  )
}
