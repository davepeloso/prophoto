"use client"

import { useState } from "react"
import type { Photo } from "@/lib/photo-data"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { X, Plus, Tags } from "lucide-react"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"

interface TagsTabProps {
  photo: Photo | null
  selectedIds: Set<string>
  allTags: string[]
  recentTags: string[]
  onAddTags: (ids: string[], tags: string[]) => void
  onRemoveTag: (ids: string[], tag: string) => void
}

export function TagsTab({ photo, selectedIds, allTags, recentTags, onAddTags, onRemoveTag }: TagsTabProps) {
  const [open, setOpen] = useState(false)
  const [inputValue, setInputValue] = useState("")

  const ids = Array.from(selectedIds)
  const currentTags = photo?.tags || []

  const handleAddTag = (tag: string) => {
    if (tag.trim()) {
      onAddTags(ids, [tag.trim()])
      setInputValue("")
      setOpen(false)
    }
  }

  const handleRemoveTag = (tag: string) => {
    onRemoveTag(ids, tag)
  }

  if (!photo && selectedIds.size === 0) {
    return (
      <div className="h-full flex items-center justify-center text-muted-foreground">
        <div className="text-center">
          <Tags className="h-12 w-12 mx-auto mb-3 opacity-40" />
          <p className="text-sm">Select photos to manage tags</p>
        </div>
      </div>
    )
  }

  return (
    <ScrollArea className="h-full">
      <div className="p-4 space-y-6">
        {/* Batch indicator */}
        {selectedIds.size > 1 && (
          <div className="bg-primary/10 text-primary text-sm px-3 py-2 rounded-md">
            Apply to {selectedIds.size} selected images
          </div>
        )}

        {/* Tag input with typeahead */}
        <div>
          <label className="text-sm font-medium mb-2 block">Add Tags</label>
          <Popover open={open} onOpenChange={setOpen}>
            <PopoverTrigger asChild>
              <Button variant="outline" className="w-full justify-start gap-2 bg-transparent">
                <Plus className="h-4 w-4" />
                Add a tag...
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-[300px] p-0" align="start">
              <Command>
                <CommandInput placeholder="Type a tag name..." value={inputValue} onValueChange={setInputValue} />
                <CommandList>
                  <CommandEmpty>
                    {inputValue && (
                      <button
                        className="w-full text-left px-4 py-2 text-sm hover:bg-accent"
                        onClick={() => handleAddTag(inputValue)}
                      >
                        Create "{inputValue}"
                      </button>
                    )}
                  </CommandEmpty>
                  <CommandGroup heading="Existing Tags">
                    {allTags
                      .filter((tag) => !currentTags.includes(tag))
                      .filter((tag) => tag.toLowerCase().includes(inputValue.toLowerCase()))
                      .map((tag) => (
                        <CommandItem key={tag} value={tag} onSelect={() => handleAddTag(tag)}>
                          {tag}
                        </CommandItem>
                      ))}
                  </CommandGroup>
                </CommandList>
              </Command>
            </PopoverContent>
          </Popover>
        </div>

        {/* Applied tags */}
        <div>
          <label className="text-sm font-medium mb-2 block">Applied Tags</label>
          {currentTags.length === 0 ? (
            <p className="text-sm text-muted-foreground">No tags applied</p>
          ) : (
            <div className="flex flex-wrap gap-2">
              {currentTags.map((tag) => (
                <Badge key={tag} variant="secondary" className="gap-1 pr-1">
                  {tag}
                  <button onClick={() => handleRemoveTag(tag)} className="ml-1 hover:bg-muted rounded-full p-0.5">
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
            </div>
          )}
        </div>

        {/* Quick tags */}
        <div>
          <label className="text-sm font-medium mb-2 block">Quick Tags</label>
          <div className="flex flex-wrap gap-2">
            {recentTags
              .filter((tag) => !currentTags.includes(tag))
              .map((tag) => (
                <button
                  key={tag}
                  onClick={() => handleAddTag(tag)}
                  className="text-xs px-2 py-1 rounded-md bg-muted hover:bg-muted/80 transition-colors"
                >
                  + {tag}
                </button>
              ))}
          </div>
        </div>
      </div>
    </ScrollArea>
  )
}
