"use client"

import { useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { 
  Upload, 
  Image as ImageIcon, 
  Calendar, 
  ChevronRight,
  Camera,
  Clock,
  MapPin,
  Check,
  Loader2,
  ArrowRight,
  Sparkles
} from "lucide-react"
import { cn } from "@/lib/utils"

interface CalendarEvent {
  id: string
  title: string
  client: string
  date: Date
  time: string
  location: string
  type: "wedding" | "portrait" | "corporate" | "event"
  matchedImages: number
  matchConfidence: "high" | "medium" | "low"
}

interface PreIngestFlowProps {
  onComplete: () => void
}

// Mock calendar events with matched image counts
const mockCalendarMatches: CalendarEvent[] = [
  {
    id: "1",
    title: "Johnson Wedding",
    client: "Sarah & Michael Johnson",
    date: new Date(2026, 3, 6),
    time: "2:00 PM",
    location: "Rosewood Gardens",
    type: "wedding",
    matchedImages: 47,
    matchConfidence: "high",
  },
  {
    id: "2",
    title: "Corporate Headshots",
    client: "Nexus Tech Inc.",
    date: new Date(2026, 3, 7),
    time: "9:00 AM",
    location: "Nexus HQ",
    type: "corporate",
    matchedImages: 32,
    matchConfidence: "high",
  },
  {
    id: "3",
    title: "Family Portrait Session",
    client: "The Martinez Family",
    date: new Date(2026, 3, 8),
    time: "4:30 PM",
    location: "Sunset Park",
    type: "portrait",
    matchedImages: 18,
    matchConfidence: "medium",
  },
  {
    id: "4",
    title: "Product Launch Event",
    client: "Aurora Cosmetics",
    date: new Date(2026, 3, 10),
    time: "6:00 PM",
    location: "Grand Ballroom",
    type: "event",
    matchedImages: 3,
    matchConfidence: "low",
  },
]

const typeColors: Record<CalendarEvent["type"], string> = {
  wedding: "bg-pink-500/20 text-pink-400 border-pink-500/30",
  portrait: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  corporate: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
  event: "bg-amber-500/20 text-amber-400 border-amber-500/30",
}

const confidenceColors = {
  high: "text-emerald-400",
  medium: "text-amber-400",
  low: "text-muted-foreground",
}

export function PreIngestFlow({ onComplete }: PreIngestFlowProps) {
  const [step, setStep] = useState<"upload" | "processing" | "match">("upload")
  const [uploadedCount, setUploadedCount] = useState(0)
  const [selectedEvent, setSelectedEvent] = useState<string | null>(null)
  const [isDragging, setIsDragging] = useState(false)

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    // Simulate upload processing
    simulateUpload()
  }, [])

  const simulateUpload = () => {
    setUploadedCount(100)
    setStep("processing")
    
    // Simulate metadata parsing delay
    setTimeout(() => {
      setStep("match")
    }, 1500)
  }

  const handleSelectEvent = (eventId: string) => {
    setSelectedEvent(eventId)
  }

  const handleConfirmMatch = () => {
    onComplete()
  }

  const handleManualSelect = () => {
    onComplete()
  }

  // Step 1: Upload Drop Zone
  if (step === "upload") {
    return (
      <div className="h-screen flex items-center justify-center bg-background p-8">
        <div className="w-full max-w-2xl">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/10 mb-4">
              <Camera className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-2xl font-semibold text-foreground mb-2">Import Photos</h1>
            <p className="text-muted-foreground">
              Drop your images to begin organizing your shoot
            </p>
          </div>

          {/* Drop Zone */}
          <div
            onClick={simulateUpload}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={cn(
              "relative cursor-pointer rounded-2xl border-2 border-dashed transition-all duration-300",
              "flex flex-col items-center justify-center py-20 px-8",
              "hover:border-primary/50 hover:bg-primary/5",
              isDragging 
                ? "border-primary bg-primary/10 scale-[1.02]" 
                : "border-border bg-card/50"
            )}
          >
            <div className={cn(
              "rounded-xl p-4 mb-4 transition-colors",
              isDragging ? "bg-primary/20" : "bg-muted"
            )}>
              <Upload className={cn(
                "w-8 h-8 transition-colors",
                isDragging ? "text-primary" : "text-muted-foreground"
              )} />
            </div>
            
            <p className="text-lg font-medium text-foreground mb-1">
              {isDragging ? "Drop to upload" : "Drag and drop your images"}
            </p>
            <p className="text-sm text-muted-foreground mb-4">
              or click to browse your files
            </p>
            
            <div className="flex items-center gap-4 text-xs text-muted-foreground">
              <span className="flex items-center gap-1.5">
                <ImageIcon className="w-3.5 h-3.5" />
                JPG, RAW, TIFF
              </span>
              <span className="w-1 h-1 rounded-full bg-border" />
              <span>Up to 1000 images</span>
            </div>
          </div>

          {/* Quick tip */}
          <p className="text-center text-xs text-muted-foreground mt-6">
            We&apos;ll automatically match your photos to calendar events based on metadata
          </p>
        </div>
      </div>
    )
  }

  // Step 1.5: Processing
  if (step === "processing") {
    return (
      <div className="h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/10 mb-6">
            <Loader2 className="w-8 h-8 text-primary animate-spin" />
          </div>
          <h2 className="text-xl font-semibold text-foreground mb-2">
            Analyzing {uploadedCount} images...
          </h2>
          <p className="text-muted-foreground">
            Reading metadata and matching to your calendar
          </p>
        </div>
      </div>
    )
  }

  // Step 2: Calendar Match
  return (
    <div className="h-screen flex items-center justify-center bg-background p-8">
      <div className="w-full max-w-2xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-primary/10 mb-4">
            <Sparkles className="w-6 h-6 text-primary" />
          </div>
          <h1 className="text-2xl font-semibold text-foreground mb-2">
            We found matches!
          </h1>
          <p className="text-muted-foreground">
            {uploadedCount} images matched to your calendar events
          </p>
        </div>

        {/* Calendar Event Matches */}
        <div className="space-y-3 mb-6">
          {mockCalendarMatches.map((event) => (
            <Card
              key={event.id}
              onClick={() => handleSelectEvent(event.id)}
              className={cn(
                "cursor-pointer transition-all duration-200",
                "hover:bg-accent/50",
                selectedEvent === event.id 
                  ? "ring-2 ring-primary bg-primary/5" 
                  : "bg-card"
              )}
            >
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    {/* Selection indicator */}
                    <div className={cn(
                      "w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors",
                      selectedEvent === event.id 
                        ? "border-primary bg-primary" 
                        : "border-border"
                    )}>
                      {selectedEvent === event.id && (
                        <Check className="w-3 h-3 text-primary-foreground" />
                      )}
                    </div>

                    {/* Event info */}
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-foreground">
                          {event.title}
                        </span>
                        <Badge 
                          variant="outline" 
                          className={cn("text-[10px] px-1.5 py-0", typeColors[event.type])}
                        >
                          {event.type}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {event.date.toLocaleDateString("en-US", { 
                            month: "short", 
                            day: "numeric" 
                          })}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {event.time}
                        </span>
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3" />
                          {event.location}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Match count */}
                  <div className="text-right">
                    <div className={cn(
                      "text-lg font-semibold",
                      confidenceColors[event.matchConfidence]
                    )}>
                      {event.matchedImages}
                    </div>
                    <div className="text-[10px] text-muted-foreground">
                      images matched
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-3">
          <Button 
            variant="outline" 
            className="flex-1"
            onClick={handleManualSelect}
          >
            Skip matching
          </Button>
          <Button 
            className="flex-1"
            disabled={!selectedEvent}
            onClick={handleConfirmMatch}
          >
            Continue with selection
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>

        {/* Footer note */}
        <p className="text-center text-xs text-muted-foreground mt-4">
          Selected event will be used to organize and tag your photos
        </p>
      </div>
    </div>
  )
}
