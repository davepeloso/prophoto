"use client"

import type { Photo } from "@/lib/photo-data"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Card, CardContent } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Camera, Aperture, Timer, Sun, Ruler, HardDrive, Calendar, MapPin } from "lucide-react"

interface MetadataTabProps {
  photo: Photo | null
}

export function MetadataTab({ photo }: MetadataTabProps) {
  if (!photo) {
    return (
      <div className="h-full flex items-center justify-center text-muted-foreground">
        <p className="text-sm">Select a photo to view metadata</p>
      </div>
    )
  }

  const formatDate = (date: string) => {
    return new Date(date).toLocaleString("en-US", {
      weekday: "short",
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
    <ScrollArea className="h-full">
      <div className="p-4 space-y-4">
        <Card>
          <CardContent className="p-4 space-y-3">
            <div className="flex items-start gap-3">
              <Calendar className="h-4 w-4 text-muted-foreground mt-0.5" />
              <div>
                <div className="text-xs text-muted-foreground">Date Taken</div>
                <div className="text-sm font-medium">{formatDate(photo.dateTaken)}</div>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Camera className="h-4 w-4 text-muted-foreground mt-0.5" />
              <div>
                <div className="text-xs text-muted-foreground">Camera</div>
                <div className="text-sm font-medium">{photo.camera}</div>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Ruler className="h-4 w-4 text-muted-foreground mt-0.5" />
              <div>
                <div className="text-xs text-muted-foreground">Lens</div>
                <div className="text-sm font-medium">{photo.lens}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <Aperture className="h-4 w-4 mx-auto text-muted-foreground mb-1" />
                <div className="text-xs text-muted-foreground">Aperture</div>
                <div className="text-sm font-medium">f/{photo.aperture}</div>
              </div>
              <div className="text-center">
                <Timer className="h-4 w-4 mx-auto text-muted-foreground mb-1" />
                <div className="text-xs text-muted-foreground">Shutter</div>
                <div className="text-sm font-medium">{photo.shutterSpeed}</div>
              </div>
              <div className="text-center">
                <Sun className="h-4 w-4 mx-auto text-muted-foreground mb-1" />
                <div className="text-xs text-muted-foreground">ISO</div>
                <div className="text-sm font-medium">{photo.iso}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 space-y-3">
            <div className="flex items-start gap-3">
              <HardDrive className="h-4 w-4 text-muted-foreground mt-0.5" />
              <div className="flex-1">
                <div className="flex justify-between">
                  <div>
                    <div className="text-xs text-muted-foreground">Dimensions</div>
                    <div className="text-sm font-medium">{photo.dimensions}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-muted-foreground">File Size</div>
                    <div className="text-sm font-medium">{photo.fileSize}</div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {photo.gps && (
          <Card>
            <CardContent className="p-4">
              <div className="flex items-start gap-3 mb-3">
                <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                <div>
                  <div className="text-xs text-muted-foreground">Location</div>
                  <div className="text-sm font-medium">{photo.gps.location}</div>
                </div>
              </div>
              <div className="aspect-video bg-muted rounded-md overflow-hidden">
                <img
                  src={`/vintage-world-map.png?height=150&width=300&query=map ${photo.gps.location}`}
                  alt="Location map"
                  className="w-full h-full object-cover"
                />
              </div>
            </CardContent>
          </Card>
        )}

        <Accordion type="single" collapsible>
          <AccordionItem value="full-exif" className="border rounded-lg px-4">
            <AccordionTrigger className="text-sm">View Full EXIF</AccordionTrigger>
            <AccordionContent>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-1 border-b border-border">
                  <span className="text-muted-foreground">Focal Length</span>
                  <span>{photo.focalLength}mm</span>
                </div>
                <div className="flex justify-between py-1 border-b border-border">
                  <span className="text-muted-foreground">Exposure Mode</span>
                  <span>Manual</span>
                </div>
                <div className="flex justify-between py-1 border-b border-border">
                  <span className="text-muted-foreground">Metering Mode</span>
                  <span>Evaluative</span>
                </div>
                <div className="flex justify-between py-1 border-b border-border">
                  <span className="text-muted-foreground">White Balance</span>
                  <span>Auto</span>
                </div>
                <div className="flex justify-between py-1 border-b border-border">
                  <span className="text-muted-foreground">Color Space</span>
                  <span>sRGB</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-muted-foreground">Filename</span>
                  <span className="truncate max-w-[150px]">{photo.filename}</span>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>
    </ScrollArea>
  )
}
