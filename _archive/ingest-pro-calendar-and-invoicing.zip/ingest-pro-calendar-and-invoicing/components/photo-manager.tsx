"use client"

import { useState, useCallback, useEffect } from "react"
import { TopActionBar } from "./top-action-bar"
import { ThumbnailBrowser } from "./thumbnail-browser"
import { ImagePreview } from "./image-preview"
import { RightPanel } from "./right-panel"
import { FilterSidebar } from "./filter-sidebar"
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from "@/components/ui/resizable"
import { type Photo, generateMockPhotos } from "@/lib/photo-data"

export function PhotoManager() {
  const [photos, setPhotos] = useState<Photo[]>([])
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set())
  const [showCulled, setShowCulled] = useState(false)
  const [sortBy, setSortBy] = useState<"date" | "camera" | "userOrder">("date")
  const [filterSidebarOpen, setFilterSidebarOpen] = useState(false)
  const [cumulativeMode, setCumulativeMode] = useState(false)
  const [ingestProgress, setIngestProgress] = useState<number | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  // Filters
  const [filters, setFilters] = useState({
    cameras: [] as string[],
    dateRange: null as [Date, Date] | null,
    apertureRange: null as [number, number] | null,
    isoRange: null as [number, number] | null,
    tags: [] as string[],
  })

  useEffect(() => {
    // Simulate loading photos
    const timer = setTimeout(() => {
      setPhotos(generateMockPhotos(124))
      setIsLoading(false)
    }, 1500)
    return () => clearTimeout(timer)
  }, [])

  const filteredPhotos = photos.filter((photo) => {
    if (!showCulled && photo.culled) return false
    if (filters.cameras.length && !filters.cameras.includes(photo.camera)) return false
    if (filters.tags.length && !filters.tags.some((t) => photo.tags.includes(t))) return false
    if (filters.isoRange) {
      if (photo.iso < filters.isoRange[0] || photo.iso > filters.isoRange[1]) return false
    }
    if (filters.apertureRange) {
      if (photo.aperture < filters.apertureRange[0] || photo.aperture > filters.apertureRange[1]) return false
    }
    return true
  })

  const sortedPhotos = [...filteredPhotos].sort((a, b) => {
    if (sortBy === "date") return new Date(b.dateTaken).getTime() - new Date(a.dateTaken).getTime()
    if (sortBy === "camera") return a.camera.localeCompare(b.camera)
    return a.userOrder - b.userOrder
  })

  const selectedPhotos = sortedPhotos.filter((p) => selectedIds.has(p.id))
  const activePhoto =
    selectedPhotos.length === 1 ? selectedPhotos[0] : selectedPhotos.length > 0 ? selectedPhotos[0] : null

  const handleSelect = useCallback(
    (id: string, multi: boolean, range: boolean) => {
      setSelectedIds((prev) => {
        const newSet = new Set(prev)
        if (range && prev.size > 0) {
          const lastSelected = Array.from(prev).pop()!
          const lastIndex = sortedPhotos.findIndex((p) => p.id === lastSelected)
          const currentIndex = sortedPhotos.findIndex((p) => p.id === id)
          const [start, end] = lastIndex < currentIndex ? [lastIndex, currentIndex] : [currentIndex, lastIndex]
          for (let i = start; i <= end; i++) {
            newSet.add(sortedPhotos[i].id)
          }
        } else if (multi || cumulativeMode) {
          if (newSet.has(id)) {
            newSet.delete(id)
          } else {
            newSet.add(id)
          }
        } else {
          newSet.clear()
          newSet.add(id)
        }
        return newSet
      })
    },
    [sortedPhotos, cumulativeMode],
  )

  const handleSelectByFilter = useCallback(
    (ids: string[], additive: boolean) => {
      setSelectedIds((prev) => {
        if (additive || cumulativeMode) {
          const newSet = new Set(prev)
          ids.forEach((id) => newSet.add(id))
          return newSet
        }
        return new Set(ids)
      })
    },
    [cumulativeMode],
  )

  const handleSelectAll = useCallback(() => {
    setSelectedIds(new Set(sortedPhotos.map((p) => p.id)))
  }, [sortedPhotos])

  const handleClearSelection = useCallback(() => {
    setSelectedIds(new Set())
  }, [])

  const handleCull = useCallback((ids: string[]) => {
    setPhotos((prev) => prev.map((p) => (ids.includes(p.id) ? { ...p, culled: !p.culled } : p)))
  }, [])

  const handleStar = useCallback((ids: string[], rating?: number) => {
    setPhotos((prev) =>
      prev.map((p) =>
        ids.includes(p.id)
          ? { ...p, starred: rating !== undefined ? rating > 0 : !p.starred, rating: rating ?? (p.starred ? 0 : 5) }
          : p,
      ),
    )
  }, [])

  const handleRotate = useCallback((ids: string[], direction: "cw" | "ccw") => {
    setPhotos((prev) =>
      prev.map((p) =>
        ids.includes(p.id) ? { ...p, rotation: (p.rotation + (direction === "cw" ? 90 : -90)) % 360 } : p,
      ),
    )
  }, [])

  const handleReorder = useCallback((fromId: string, toId: string) => {
    setPhotos((prev) => {
      const fromIndex = prev.findIndex((p) => p.id === fromId)
      const toIndex = prev.findIndex((p) => p.id === toId)
      const newPhotos = [...prev]
      const [moved] = newPhotos.splice(fromIndex, 1)
      newPhotos.splice(toIndex, 0, moved)
      return newPhotos.map((p, i) => ({ ...p, userOrder: i }))
    })
  }, [])

  const handleAddTags = useCallback((ids: string[], tags: string[]) => {
    setPhotos((prev) => prev.map((p) => (ids.includes(p.id) ? { ...p, tags: [...new Set([...p.tags, ...tags])] } : p)))
  }, [])

  const handleRemoveTag = useCallback((ids: string[], tag: string) => {
    setPhotos((prev) => prev.map((p) => (ids.includes(p.id) ? { ...p, tags: p.tags.filter((t) => t !== tag) } : p)))
  }, [])

  const handleAddPhotos = useCallback(
    (files: FileList) => {
      // Simulate adding photos
      const newPhotos = generateMockPhotos(files.length, photos.length)
      setPhotos((prev) => [...prev, ...newPhotos])
    },
    [photos.length],
  )

  const handleIngest = useCallback(() => {
    setIngestProgress(0)
    const selectedCount = selectedIds.size
    let progress = 0
    const interval = setInterval(() => {
      progress += Math.random() * 15
      if (progress >= 100) {
        setIngestProgress(null)
        clearInterval(interval)
      } else {
        setIngestProgress(progress)
      }
    }, 200)
  }, [selectedIds.size])

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return

      const ids = Array.from(selectedIds)
      if (e.key === "c" || e.key === "C") {
        handleCull(ids)
      } else if (e.key === "s" || e.key === "S") {
        handleStar(ids)
      } else if (e.key === "ArrowLeft") {
        const currentIndex = sortedPhotos.findIndex((p) => selectedIds.has(p.id))
        if (currentIndex > 0) {
          handleSelect(sortedPhotos[currentIndex - 1].id, false, false)
        }
      } else if (e.key === "ArrowRight") {
        const currentIndex = sortedPhotos.findIndex((p) => selectedIds.has(p.id))
        if (currentIndex < sortedPhotos.length - 1) {
          handleSelect(sortedPhotos[currentIndex + 1].id, false, false)
        }
      }
    }
    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [selectedIds, sortedPhotos, handleCull, handleStar, handleSelect])

  const allTags = [...new Set(photos.flatMap((p) => p.tags))]
  const recentTags = allTags.slice(0, 8)

  return (
    <div className="h-screen flex flex-col bg-background text-foreground">
      <TopActionBar
        totalCount={sortedPhotos.length}
        selectedCount={selectedIds.size}
        showCulled={showCulled}
        onShowCulledChange={setShowCulled}
        sortBy={sortBy}
        onSortChange={setSortBy}
        onSelectAll={handleSelectAll}
        onClearSelection={handleClearSelection}
        onAddPhotos={handleAddPhotos}
        onIngest={handleIngest}
        ingestProgress={ingestProgress}
        onToggleFilterSidebar={() => setFilterSidebarOpen(!filterSidebarOpen)}
        filterSidebarOpen={filterSidebarOpen}
      />

      <div className="flex-1 flex overflow-hidden">
        <FilterSidebar
          open={filterSidebarOpen}
          onClose={() => setFilterSidebarOpen(false)}
          photos={photos}
          filters={filters}
          onFiltersChange={setFilters}
        />

        <ResizablePanelGroup direction="horizontal" className="flex-1">
          <ResizablePanel defaultSize={20} minSize={15} maxSize={30}>
            <ThumbnailBrowser
              photos={sortedPhotos}
              selectedIds={selectedIds}
              onSelect={handleSelect}
              onCull={handleCull}
              onStar={handleStar}
              onRotate={handleRotate}
              onReorder={handleReorder}
              isLoading={isLoading}
            />
          </ResizablePanel>

          <ResizableHandle withHandle />

          <ResizablePanel defaultSize={45} minSize={30}>
            <ImagePreview
              photo={activePhoto}
              selectedPhotos={selectedPhotos}
              onCull={handleCull}
              onStar={handleStar}
              onRotate={handleRotate}
            />
          </ResizablePanel>

          <ResizableHandle withHandle />

          <ResizablePanel defaultSize={35} minSize={25} maxSize={45}>
            <RightPanel
              photo={activePhoto}
              selectedIds={selectedIds}
              photos={sortedPhotos}
              allTags={allTags}
              recentTags={recentTags}
              onSelectByFilter={handleSelectByFilter}
              onAddTags={handleAddTags}
              onRemoveTag={handleRemoveTag}
              cumulativeMode={cumulativeMode}
              onCumulativeModeChange={setCumulativeMode}
              isLoading={isLoading}
            />
          </ResizablePanel>
        </ResizablePanelGroup>
      </div>
    </div>
  )
}
