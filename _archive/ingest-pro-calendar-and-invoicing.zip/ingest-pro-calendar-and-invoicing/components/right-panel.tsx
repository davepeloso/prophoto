"use client"

import type { Photo } from "@/lib/photo-data"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CalendarTab } from "./calendar-tab"
import { TagsTab } from "./tags-tab"
import { ChartsTab } from "./charts-tab"

interface RightPanelProps {
  photo: Photo | null
  selectedIds: Set<string>
  photos: Photo[]
  allTags: string[]
  recentTags: string[]
  onSelectByFilter: (ids: string[], additive: boolean) => void
  onAddTags: (ids: string[], tags: string[]) => void
  onRemoveTag: (ids: string[], tag: string) => void
  cumulativeMode: boolean
  onCumulativeModeChange: (mode: boolean) => void
  isLoading: boolean
}

export function RightPanel({
  photo,
  selectedIds,
  photos,
  allTags,
  recentTags,
  onSelectByFilter,
  onAddTags,
  onRemoveTag,
  cumulativeMode,
  onCumulativeModeChange,
  isLoading,
}: RightPanelProps) {
  return (
    <div className="h-full border-l border-border bg-card">
      <Tabs defaultValue="charts" className="h-full flex flex-col">
        <TabsList className="w-full rounded-none border-b border-border bg-transparent h-10 p-0">
          <TabsTrigger
            value="calendar"
            className="flex-1 rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent"
          >
            Calendar
          </TabsTrigger>
          <TabsTrigger
            value="tags"
            className="flex-1 rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent"
          >
            Tags
          </TabsTrigger>
          <TabsTrigger
            value="charts"
            className="flex-1 rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent"
          >
            Charts
          </TabsTrigger>
        </TabsList>

        <TabsContent value="calendar" className="flex-1 overflow-hidden mt-0">
          <CalendarTab />
        </TabsContent>

        <TabsContent value="tags" className="flex-1 overflow-hidden mt-0">
          <TagsTab
            photo={photo}
            selectedIds={selectedIds}
            allTags={allTags}
            recentTags={recentTags}
            onAddTags={onAddTags}
            onRemoveTag={onRemoveTag}
          />
        </TabsContent>

        <TabsContent value="charts" className="flex-1 overflow-hidden mt-0">
          <ChartsTab
            photos={photos}
            selectedIds={selectedIds}
            onSelectByFilter={onSelectByFilter}
            cumulativeMode={cumulativeMode}
            onCumulativeModeChange={onCumulativeModeChange}
            isLoading={isLoading}
          />
        </TabsContent>
      </Tabs>
    </div>
  )
}
