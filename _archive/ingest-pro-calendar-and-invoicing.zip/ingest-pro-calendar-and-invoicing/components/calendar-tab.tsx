"use client"

import { useState } from "react"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { 
  CalendarDays, 
  ChevronLeft, 
  ChevronRight, 
  DollarSign, 
  FileText, 
  Send, 
  User,
  Clock,
  MapPin
} from "lucide-react"
import { cn } from "@/lib/utils"

interface CalendarEvent {
  id: string
  title: string
  client: string
  email: string
  date: Date
  time: string
  duration: string
  location: string
  type: "wedding" | "portrait" | "corporate" | "event"
  status: "confirmed" | "pending" | "completed"
  rate: number
}

// Sample photography events for the current week
const sampleEvents: CalendarEvent[] = [
  {
    id: "1",
    title: "Johnson Wedding",
    client: "Sarah & Michael Johnson",
    email: "sarah.johnson@email.com",
    date: new Date(2026, 3, 6), // April 6
    time: "2:00 PM",
    duration: "6 hours",
    location: "Rosewood Gardens",
    type: "wedding",
    status: "confirmed",
    rate: 3500,
  },
  {
    id: "2",
    title: "Corporate Headshots",
    client: "Nexus Tech Inc.",
    email: "hr@nexustech.com",
    date: new Date(2026, 3, 7), // April 7
    time: "9:00 AM",
    duration: "4 hours",
    location: "Nexus HQ, Downtown",
    type: "corporate",
    status: "confirmed",
    rate: 1200,
  },
  {
    id: "3",
    title: "Family Portrait Session",
    client: "The Martinez Family",
    email: "maria.martinez@email.com",
    date: new Date(2026, 3, 8), // April 8
    time: "4:30 PM",
    duration: "2 hours",
    location: "Sunset Park",
    type: "portrait",
    status: "pending",
    rate: 450,
  },
  {
    id: "4",
    title: "Product Launch Event",
    client: "Aurora Cosmetics",
    email: "events@auroracosmetics.com",
    date: new Date(2026, 3, 10), // April 10
    time: "6:00 PM",
    duration: "3 hours",
    location: "Grand Ballroom Hotel",
    type: "event",
    status: "confirmed",
    rate: 1800,
  },
  {
    id: "5",
    title: "Engagement Shoot",
    client: "Emma & David Chen",
    email: "emma.chen@email.com",
    date: new Date(2026, 3, 11), // April 11
    time: "5:00 PM",
    duration: "2 hours",
    location: "Botanical Gardens",
    type: "portrait",
    status: "confirmed",
    rate: 600,
  },
]

const typeColors: Record<CalendarEvent["type"], string> = {
  wedding: "bg-pink-500/20 text-pink-700 dark:text-pink-300 border-pink-500/30",
  portrait: "bg-blue-500/20 text-blue-700 dark:text-blue-300 border-blue-500/30",
  corporate: "bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border-emerald-500/30",
  event: "bg-amber-500/20 text-amber-700 dark:text-amber-300 border-amber-500/30",
}

const statusColors: Record<CalendarEvent["status"], string> = {
  confirmed: "bg-green-500/20 text-green-700 dark:text-green-300",
  pending: "bg-yellow-500/20 text-yellow-700 dark:text-yellow-300",
  completed: "bg-muted text-muted-foreground",
}

export function CalendarTab() {
  const [selectedEvent, setSelectedEvent] = useState<CalendarEvent | null>(null)
  const [currentWeekStart, setCurrentWeekStart] = useState(() => {
    const today = new Date(2026, 3, 10) // April 10, 2026 (Friday)
    const day = today.getDay()
    const diff = today.getDate() - day + (day === 0 ? -6 : 1)
    return new Date(today.setDate(diff))
  })

  const getWeekDays = () => {
    const days = []
    for (let i = 0; i < 7; i++) {
      const day = new Date(currentWeekStart)
      day.setDate(currentWeekStart.getDate() + i)
      days.push(day)
    }
    return days
  }

  const weekDays = getWeekDays()
  const dayNames = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

  const getEventsForDay = (date: Date) => {
    return sampleEvents.filter(
      (event) =>
        event.date.getDate() === date.getDate() &&
        event.date.getMonth() === date.getMonth() &&
        event.date.getFullYear() === date.getFullYear()
    )
  }

  const navigateWeek = (direction: "prev" | "next") => {
    const newStart = new Date(currentWeekStart)
    newStart.setDate(currentWeekStart.getDate() + (direction === "next" ? 7 : -7))
    setCurrentWeekStart(newStart)
  }

  const formatMonthYear = () => {
    const endOfWeek = new Date(currentWeekStart)
    endOfWeek.setDate(currentWeekStart.getDate() + 6)
    
    if (currentWeekStart.getMonth() === endOfWeek.getMonth()) {
      return currentWeekStart.toLocaleDateString("en-US", { month: "long", year: "numeric" })
    }
    return `${currentWeekStart.toLocaleDateString("en-US", { month: "short" })} - ${endOfWeek.toLocaleDateString("en-US", { month: "short", year: "numeric" })}`
  }

  const isToday = (date: Date) => {
    const today = new Date(2026, 3, 10) // Simulating "today" as April 10, 2026
    return (
      date.getDate() === today.getDate() &&
      date.getMonth() === today.getMonth() &&
      date.getFullYear() === today.getFullYear()
    )
  }

  return (
    <ScrollArea className="h-full">
      <div className="p-3 space-y-2">
        {/* Week Calendar Header */}
        <Card className="shadow-none py-0 mb-[14px]">
          <CardHeader className="p-2 pb-0">
            <div className="flex items-center justify-between">
              <CardTitle className="text-[7px] font-medium flex items-center gap-1.5">
                <CalendarDays className="h-3.5 w-3.5 text-primary" />
                Week Schedule
              </CardTitle>
              <div className="flex items-center gap-0.5">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6"
                  onClick={() => navigateWeek("prev")}
                >
                  <ChevronLeft className="h-3.5 w-3.5" />
                </Button>
                <span className="text-[10px] font-medium min-w-[100px] text-center">
                  {formatMonthYear()}
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6"
                  onClick={() => navigateWeek("next")}
                >
                  <ChevronRight className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-2 pt-0 pb-2.5 px-0">
            {/* Week Grid */}
            <div className="grid grid-cols-7 gap-0.5 font-semibold leading-[2.2em]">
              {/* Day Headers */}
              {dayNames.map((day) => (
                <div
                  key={day}
                  className="text-center text-[9px] font-medium text-muted-foreground py-0.5"
                >
                  {day}
                </div>
              ))}
              {/* Day Cells */}
              {weekDays.map((date, index) => {
                const events = getEventsForDay(date)
                const hasEvents = events.length > 0
                return (
                  <button
                    key={index}
                    onClick={() => hasEvents && setSelectedEvent(events[0])}
                    className={cn(
                      "relative flex flex-col items-center p-0.5 rounded transition-colors min-h-[40px]",
                      isToday(date) && "bg-primary/10 ring-1 ring-primary/30",
                      hasEvents && "cursor-pointer hover:bg-accent",
                      !hasEvents && "opacity-60"
                    )}
                  >
                    <span
                      className={cn(
                        "text-[10px] font-medium",
                        isToday(date) && "text-primary"
                      )}
                    >
                      {date.getDate()}
                    </span>
                    {events.map((event, i) => (
                      <div
                        key={event.id}
                        className={cn(
                          "w-full mt-0.5 rounded px-0.5 text-[7px] leading-tight truncate border",
                          typeColors[event.type],
                          selectedEvent?.id === event.id && "ring-1 ring-primary"
                        )}
                        title={event.title}
                      >
                        {event.time.replace(" PM", "p").replace(" AM", "a")}
                      </div>
                    ))}
                  </button>
                )
              })}
            </div>
          </CardContent>
        </Card>

        {/* Selected Event Details */}
        {selectedEvent ? (
          <Card className="shadow-none py-0 pt-1.5 pb-0">
            <CardContent className="p-2">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium truncate">{selectedEvent.title}</p>
                  <div className="flex items-center gap-2 text-[10px] text-muted-foreground mt-0.5">
                    <span className="flex items-center gap-1">
                      <Clock className="h-2.5 w-2.5" />
                      {selectedEvent.time}
                    </span>
                    <span className="flex items-center gap-1">
                      <MapPin className="h-2.5 w-2.5" />
                      <span className="truncate max-w-[80px]">{selectedEvent.location}</span>
                    </span>
                  </div>
                  <div className="flex items-center gap-1 text-[10px] mt-0.5">
                    <User className="h-2.5 w-2.5 text-muted-foreground" />
                    <span className="truncate">{selectedEvent.client}</span>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <Badge variant="outline" className={cn("text-[9px] px-1 py-0", typeColors[selectedEvent.type])}>
                    {selectedEvent.type}
                  </Badge>
                  <Badge variant="secondary" className={cn("text-[9px] px-1 py-0", statusColors[selectedEvent.status])}>
                    {selectedEvent.status}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="text-[10px] text-muted-foreground text-center py-1">
            Select an event to view details
          </div>
        )}

        {/* Invoicing Section */}
        <Card className="shadow-none py-0 pb-0">
          <CardHeader className="p-2 pb-0">
            <CardTitle className="text-xs font-medium flex items-center gap-1.5">
              <DollarSign className="h-3.5 w-3.5 text-primary" />
              Invoicing
            </CardTitle>
          </CardHeader>
          <CardContent className="p-2 pt-0 space-y-2">
            {selectedEvent ? (
              <>
                {/* Invoice Preview */}
                <div className="rounded border border-border bg-muted/30 p-2 space-y-1">
                  <div className="flex justify-between text-[10px]">
                    <span className="text-muted-foreground">Client</span>
                    <span className="font-medium truncate max-w-[120px]">{selectedEvent.client}</span>
                  </div>
                  <div className="flex justify-between text-[10px]">
                    <span className="text-muted-foreground">Email</span>
                    <span className="font-medium truncate max-w-[120px]">{selectedEvent.email}</span>
                  </div>
                  <div className="flex justify-between text-[10px]">
                    <span className="text-muted-foreground">Service</span>
                    <span className="font-medium capitalize">{selectedEvent.type}</span>
                  </div>
                  <div className="flex justify-between text-[10px]">
                    <span className="text-muted-foreground">Date</span>
                    <span className="font-medium">
                      {selectedEvent.date.toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                    </span>
                  </div>
                  <div className="border-t border-border pt-1 mt-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-medium">Total</span>
                      <span className="font-bold text-primary">${selectedEvent.rate.toLocaleString()}</span>
                    </div>
                  </div>
                </div>

                {/* Invoice Actions */}
                <div className="flex gap-1.5">
                  <Button variant="outline" size="sm" className="flex-1 text-[10px] h-7">
                    <FileText className="h-3 w-3 mr-1" />
                    Draft
                  </Button>
                  <Button size="sm" className="flex-1 text-[10px] h-7">
                    <Send className="h-3 w-3 mr-1" />
                    Send via Stripe
                  </Button>
                </div>
              </>
            ) : (
              <div className="py-2 text-center">
                <p className="text-[10px] text-muted-foreground">
                  Select event to create invoice
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </ScrollArea>
  )
}
