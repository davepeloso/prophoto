"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Upload, Filter, ImagePlus } from "lucide-react"
import { useRef, useCallback } from "react"

interface TopActionBarProps {
  totalCount: number
  selectedCount: number
  showCulled: boolean
  onShowCulledChange: (show: boolean) => void
  sortBy: "date" | "camera" | "userOrder"
  onSortChange: (sort: "date" | "camera" | "userOrder") => void
  onSelectAll: () => void
  onClearSelection: () => void
  onAddPhotos: (files: FileList) => void
  onIngest: () => void
  ingestProgress: number | null
  onToggleFilterSidebar: () => void
  filterSidebarOpen: boolean
}

export function TopActionBar({
  totalCount,
  selectedCount,
  showCulled,
  onShowCulledChange,
  sortBy,
  onSortChange,
  onSelectAll,
  onClearSelection,
  onAddPhotos,
  onIngest,
  ingestProgress,
  onToggleFilterSidebar,
  filterSidebarOpen,
}: TopActionBarProps) {
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      if (e.dataTransfer.files.length) {
        onAddPhotos(e.dataTransfer.files)
      }
    },
    [onAddPhotos],
  )

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
  }, [])

  return (
    <div
      className="h-14 border-b border-border bg-card px-4 flex items-center gap-4"
      onDrop={handleDrop}
      onDragOver={handleDragOver}
    >
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        className="hidden"
        onChange={(e) => e.target.files && onAddPhotos(e.target.files)}
      />

      <Button variant="outline" size="sm" onClick={() => fileInputRef.current?.click()} className="gap-2">
        <ImagePlus className="h-4 w-4" />
        Add Photos
      </Button>

      <Button
        variant={filterSidebarOpen ? "secondary" : "ghost"}
        size="sm"
        onClick={onToggleFilterSidebar}
        className="gap-2"
      >
        <Filter className="h-4 w-4" />
        Filters
      </Button>

      <div className="h-6 w-px bg-border" />

      <div className="flex items-center gap-2">
        <Switch id="show-culled" checked={showCulled} onCheckedChange={onShowCulledChange} />
        <Label htmlFor="show-culled" className="text-sm text-muted-foreground">
          Show Culled
        </Label>
      </div>

      <Select value={sortBy} onValueChange={onSortChange as (value: string) => void}>
        <SelectTrigger className="w-[140px] h-8">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="date">Date Taken</SelectItem>
          <SelectItem value="camera">Camera</SelectItem>
          <SelectItem value="userOrder">User Order</SelectItem>
        </SelectContent>
      </Select>

      <div className="flex-1" />

      <div className="flex items-center gap-2 text-sm">
        <span className="text-muted-foreground">
          <span className="font-medium text-foreground">{selectedCount}</span> of {totalCount} selected
        </span>
        <button onClick={onSelectAll} className="text-primary hover:underline underline-offset-2">
          Select All
        </button>
        <span className="text-muted-foreground">•</span>
        <button onClick={onClearSelection} className="text-primary hover:underline underline-offset-2">
          Clear
        </button>
      </div>

      <div className="h-6 w-px bg-border" />

      {ingestProgress !== null ? (
        <div className="flex items-center gap-3 min-w-[200px]">
          <Progress value={ingestProgress} className="flex-1 h-2" />
          <span className="text-sm text-muted-foreground whitespace-nowrap">{Math.round(ingestProgress)}%</span>
        </div>
      ) : (
        <Button size="sm" disabled={selectedCount === 0} onClick={onIngest} className="gap-2">
          <Upload className="h-4 w-4" />
          Ingest Selected
        </Button>
      )}
    </div>
  )
}
